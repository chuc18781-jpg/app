const { app, BrowserWindow, Menu } = require("electron");
const path = require("path");
function create() {
  const w = new BrowserWindow({ width: 560, height: 820, title: "Key 24 Giờ",
    icon: path.join(__dirname, "..", "www", "icon-512.png"), webPreferences: { contextIsolation: true } });
  Menu.setApplicationMenu(null);
  w.loadFile(path.join(__dirname, "..", "www", "index.html"));
}
app.whenReady().then(create);
app.on("window-all-closed", () => app.quit());
