# Key 24 Giờ: hướng dẫn đóng gói thành ứng dụng cài đặt

Thư mục `www/` là ứng dụng (HTML thuần, chạy không cần mạng). Hai cách đóng gói bên dưới đều cần máy có internet để tải công cụ, và cần cài Node.js (https://nodejs.org, bản LTS).

## Cách 1: Windows (.exe)
Mở Terminal trong thư mục này rồi chạy:

    npm install
    npm start              # chạy thử cửa sổ app
    npm run build:win      # tạo file cài đặt

File cài đặt nằm trong `dist/` (ví dụ `Key 24 Giờ Setup 1.0.0.exe`). Muốn ra macOS hoặc Linux thì dùng `build:mac` / `build:linux` trên đúng hệ điều hành đó.

## Cách 2: Android (.apk)
Cần cài thêm Android Studio (kèm Android SDK) và JDK 17.

    npm install @capacitor/core @capacitor/cli @capacitor/android
    npx cap add android
    npx cap sync android
    npx cap open android

Trong Android Studio chọn **Build > Build Bundle(s) / APK(s) > Build APK(s)**. File `.apk` nằm ở `android/app/build/outputs/apk/debug/`. Chép sang điện thoại rồi cài (bật "Cài từ nguồn không xác định").
Muốn đẩy lên Google Play thì dùng **Build > Generate Signed Bundle** để tạo file `.aab` có chữ ký.

## Cách 3 (nhanh nhất, không cần công cụ): cài như PWA
Đưa thư mục `www/` lên một địa chỉ https bất kỳ (GitHub Pages, Netlify, Cloudflare Pages). Mở địa chỉ đó bằng Chrome:
- Android: menu ⋮ > "Cài đặt ứng dụng".
- Windows/Mac: biểu tượng cài đặt ở thanh địa chỉ.
- iPhone: Safari > Chia sẻ > "Thêm vào MH chính".

## Lưu ý
- Đổi `appId` (`vn.example.key24gio`) trong `package.json` và `capacitor.config.json` thành mã riêng của bạn trước khi phát hành.
- Key trong bản này được tạo và kiểm tra ngay trên thiết bị, nên chưa phải hệ thống bản quyền thật.
